#include <stdio.h>
#include <time.h> // Para medir o tempo
#include "leitura_arquivo.h"

int main() {
    tipo_lista lista;
    ler_dados(&lista);

    // Criar tabela hash
    hash_table *tabela = criar_tabela_hash();

    // Processar o arquivo de avaliações
    processar_avaliacoes(tabela, "ratings.csv");

    // Calcular as médias e atualizar a lista
    calcular_medias(tabela, &lista);

    // Liberar a tabela hash
    liberar_tabela_hash(tabela);

    // Continuar com o menu de ordenação...
    int escolha_criterio, escolha_algoritmo;

    do {
        printf("Escolha o critério de ordenação:\n");
        printf("1. Título\n");
        printf("2. Ano\n");
        printf("3. Avaliação\n");
        printf("4. Sair\n");
        scanf("%d", &escolha_criterio);

        if (escolha_criterio == 4) break;

        printf("Escolha o algoritmo de ordenação:\n");
        printf("1. Quick Sort\n");
        printf("2. Merge Sort\n");
        printf("3. Shell Sort\n");
        scanf("%d", &escolha_algoritmo);

        int (*comparar)(const void *, const void *);
        switch (escolha_criterio) {
            case 1: comparar = comparar_por_titulo; break;
            case 2: comparar = comparar_por_ano; break; // Corrigido: atribuir a função à variável
            case 3: comparar = comparar_por_avaliacao; break;
            default: printf("Critério inválido.\n"); continue;
        }

        clock_t inicio, fim; // Variáveis para medir o tempo
        double tempo_decorrido;

        // Medir o tempo do algoritmo de ordenação
        inicio = clock();
        switch (escolha_algoritmo) {
            case 1: quick_sort(lista.vet, 0, lista.tamanho - 1, comparar); break;
            case 2: merge_sort(lista.vet, 0, lista.tamanho - 1, comparar); break;
            case 3: shell_sort(lista.vet, lista.tamanho, comparar); break;
            default: printf("Algoritmo inválido.\n"); continue;
        }
        fim = clock();

        // Calcular o tempo decorrido
        tempo_decorrido = (double)(fim - inicio) / CLOCKS_PER_SEC;
        printf("Tempo de execução da ordenação: %.6f segundos\n", tempo_decorrido);

        if (escolha_criterio == 2) { // Ordenação por ano
            int removidos = remover_filmes_sem_ano(&lista);
            printf("Filmes sem ano removidos: %d\n", removidos);
        }

        if (escolha_criterio == 3) { // Ordenação por avaliação
            int removidos = remover_filmes_sem_avaliacao(&lista);
            printf("Filmes sem avaliação removidos: %d\n", removidos);
        }

        printf("Primeiros 10 filmes ordenados:\n");
        for (int i = 0; i < 10 && i < lista.tamanho; i++) {
            printf("ID: %d, Título: %s, Ano: %d, Avaliação: %.2f\n",
                   lista.vet[i].movieID, lista.vet[i].movieTitle, lista.vet[i].ano, lista.vet[i].avaliacao);
        }

    } while (escolha_criterio != 4);

    free(lista.vet);
    return 0;
}