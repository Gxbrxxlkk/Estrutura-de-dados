#ifndef __LEITURA_ARQUIVO_H__
#define __LEITURA_ARQUIVO_H__

#include <stdio.h>
#include <stdlib.h>

#define TAM 288983  ///< Tamanho inicial da lista de filmes (definido manualmente).
#define HASH_SIZE 100000 ///< Tamanho da tabela hash (definido manualmente).

/**
 * @brief Estrutura que representa os dados de um filme.
 */
typedef struct {
    int movieID;               ///< ID do filme.
    char movieTitle[250];      ///< Título do filme.
    char genres[250];          ///< Gêneros do filme.
    int ano;                   ///< Ano do filme.
    float avaliacao;           ///< Média de avaliação do filme.
} tipo_dados;

/**
 * @brief Estrutura que representa uma lista de filmes.
 */
typedef struct {
    tipo_dados* vet;           ///< Vetor de filmes.
    int tamanho;               ///< Quantidade de filmes na lista.
} tipo_lista;

/**
 * @brief Estrutura que representa uma entrada na tabela hash.
 */
typedef struct hash_entry {
    int movieID;               ///< ID do filme.
    float soma_avaliacoes;     ///< Soma das avaliações do filme.
    int num_avaliacoes;        ///< Número de avaliações do filme.
    struct hash_entry *next;   ///< Ponteiro para a próxima entrada (em caso de colisão).
} hash_entry;

/**
 * @brief Estrutura que representa a tabela hash.
 */
typedef struct {
    hash_entry **entries;      ///< Vetor de ponteiros para entradas da tabela hash.
} hash_table;

/**
 * @brief Lê os dados dos filmes a partir de um arquivo CSV.
 * 
 * @param lista Ponteiro para a estrutura que armazenará os filmes.
 * @note O nome do arquivo CSV está definido manualmente no código-fonte.
 */
void ler_dados(tipo_lista* lista);

/**
 * @brief Calcula as avaliações médias dos filmes na lista.
 * 
 * @param lista Ponteiro para a lista de filmes.
 * @note O nome do arquivo de avaliações está definido manualmente no código-fonte.
 */
void calcular_avaliacoes(tipo_lista *lista);

/**
 * @brief Extrai o ano de um título de filme.
 * 
 * @param titulo String contendo o título do filme.
 * @return O ano extraído ou 0 se não for encontrado.
 */
int extrair_ano(const char *titulo);

/**
 * @brief Cria uma tabela hash.
 * 
 * @return Ponteiro para a tabela hash criada.
 */
hash_table* criar_tabela_hash();

/**
 * @brief Insere ou atualiza uma entrada na tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash.
 * @param movieID ID do filme.
 * @param avaliacao Avaliação do filme.
 */
void inserir_ou_atualizar(hash_table *tabela, int movieID, float avaliacao);

/**
 * @brief Busca uma entrada na tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash.
 * @param movieID ID do filme a ser buscado.
 * @return Ponteiro para a entrada encontrada ou NULL se não for encontrada.
 */
hash_entry* buscar(hash_table *tabela, int movieID);

/**
 * @brief Libera a memória alocada para a tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash.
 */
void liberar_tabela_hash(hash_table *tabela);

/**
 * @brief Processa as avaliações de um arquivo CSV e insere na tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash.
 * @param arquivo_avaliacoes Nome do arquivo CSV contendo as avaliações.
 * @note O nome do arquivo CSV está definido manualmente no código-fonte.
 */
void processar_avaliacoes(hash_table *tabela, const char *arquivo_avaliacoes);

/**
 * @brief Calcula as médias de avaliação dos filmes na lista usando a tabela hash.
 * 
 * @param tabela Ponteiro para a tabela hash.
 * @param lista Ponteiro para a lista de filmes.
 */
void calcular_medias(hash_table *tabela, tipo_lista *lista);

/**
 * @brief Ordena a lista de filmes usando o Quick Sort.
 * 
 * @param vet Vetor de filmes.
 * @param low Índice inicial.
 * @param high Índice final.
 * @param comparar Função de comparação.
 */
void quick_sort(tipo_dados *vet, int low, int high, int (*comparar)(const void *, const void *));

/**
 * @brief Ordena a lista de filmes usando o Merge Sort.
 * 
 * @param vet Vetor de filmes.
 * @param left Índice inicial.
 * @param right Índice final.
 * @param comparar Função de comparação.
 */
void merge_sort(tipo_dados *vet, int left, int right, int (*comparar)(const void *, const void *));

/**
 * @brief Ordena a lista de filmes usando o Shell Sort.
 * 
 * @param vet Vetor de filmes.
 * @param tamanho Tamanho do vetor.
 * @param comparar Função de comparação.
 */
void shell_sort(tipo_dados *vet, int tamanho, int (*comparar)(const void *, const void *));

/**
 * @brief Função auxiliar para o Merge Sort.
 * 
 * @param vet Vetor de filmes.
 * @param left Índice inicial.
 * @param mid Índice do meio.
 * @param right Índice final.
 * @param comparar Função de comparação.
 */
void merge(tipo_dados *vet, int left, int mid, int right, int (*comparar)(const void *, const void *));

/**
 * @brief Função auxiliar para o Quick Sort.
 * 
 * @param vet Vetor de filmes.
 * @param low Índice inicial.
 * @param high Índice final.
 * @param comparar Função de comparação.
 * @return Índice do pivô.
 */
int partition(tipo_dados *vet, int low, int high, int (*comparar)(const void *, const void *));

/**
 * @brief Compara dois filmes pelo título.
 * 
 * @param a Ponteiro para o primeiro filme.
 * @param b Ponteiro para o segundo filme.
 * @return Valor negativo, zero ou positivo dependendo da ordem.
 */
int comparar_por_titulo(const void *a, const void *b);

/**
 * @brief Remove filmes sem ano da lista.
 * 
 * @param lista Ponteiro para a lista de filmes.
 * @return Quantidade de filmes removidos.
 */
int remover_filmes_sem_ano(tipo_lista *lista);

/**
 * @brief Compara dois filmes pela avaliação.
 * 
 * @param a Ponteiro para o primeiro filme.
 * @param b Ponteiro para o segundo filme.
 * @return Valor negativo, zero ou positivo dependendo da ordem.
 */
int comparar_por_avaliacao(const void *a, const void *b);

/**
 * @brief Remove filmes sem avaliação da lista.
 * 
 * @param lista Ponteiro para a lista de filmes.
 * @return Quantidade de filmes removidos.
 */
int remover_filmes_sem_avaliacao(tipo_lista *lista);

/**
 * @brief Compara dois filmes pelo ano.
 * 
 * @param a Ponteiro para o primeiro filme.
 * @param b Ponteiro para o segundo filme.
 * @return Valor negativo, zero ou positivo dependendo da ordem.
 */
int comparar_por_ano(const void *a, const void *b);

#endif
