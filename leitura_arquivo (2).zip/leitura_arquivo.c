#include "leitura_arquivo.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>

// Criar a tabela hash
hash_table* criar_tabela_hash() {
    hash_table *tabela = malloc(sizeof(hash_table));
    tabela->entries = calloc(HASH_SIZE, sizeof(hash_entry *));
    return tabela;
}

// Função de hash
int hash_function(int movieID) {
    return movieID % HASH_SIZE;
}

// Inserir ou atualizar na tabela hash
void inserir_ou_atualizar(hash_table *tabela, int movieID, float avaliacao) {
    int index = hash_function(movieID);

    // Procurar por uma entrada existente
    hash_entry *entry = tabela->entries[index];
    while (entry != NULL) {
        if (entry->movieID == movieID) {
            // Atualizar soma e número de avaliações
            entry->soma_avaliacoes += avaliacao;
            entry->num_avaliacoes++;
            return;
        }
        entry = entry->next;
    }

    // Criar uma nova entrada se não existir
    hash_entry *nova_entry = malloc(sizeof(hash_entry));
    nova_entry->movieID = movieID;
    nova_entry->soma_avaliacoes = avaliacao;
    nova_entry->num_avaliacoes = 1;
    nova_entry->next = tabela->entries[index];
    tabela->entries[index] = nova_entry;
}

// Buscar na tabela hash
hash_entry* buscar(hash_table *tabela, int movieID) {
    int index = hash_function(movieID);
    hash_entry *entry = tabela->entries[index];

    while (entry != NULL) {
        if (entry->movieID == movieID) {
            return entry;
        }
        entry = entry->next;
    }
    return NULL; // Não encontrado
}

// Liberar a tabela hash
void liberar_tabela_hash(hash_table *tabela) {
    for (int i = 0; i < HASH_SIZE; i++) {
        hash_entry *entry = tabela->entries[i];
        while (entry != NULL) {
            hash_entry *temp = entry;
            entry = entry->next;
            free(temp);
        }
    }
    free(tabela->entries);
    free(tabela);
}

void ler_dados(tipo_lista* lista) {
    FILE *arquivo = fopen("movies.csv", "r");
    if (!arquivo) {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    lista->vet = (tipo_dados*)malloc(TAM * sizeof(tipo_dados));
    if (!lista->vet) {
        printf("Erro ao alocar memória.\n");
        fclose(arquivo);
        return;
    }
    lista->tamanho = 0;
    char linha[1024];
    while (fgets(linha, sizeof(linha), arquivo)) {
        char *id_str = NULL;
        char *titulo = NULL;
        char *generos = NULL;

        // Ignorar a linha do cabeçalho
        if (lista->tamanho == 0 && strstr(linha, "movieId") != NULL) {
            continue;
        }

        // Extrair o ID do filme
        id_str = strtok(linha, ",");
        if (id_str == NULL) {
            continue; // Linha inválida
        }

        // Verificar se o título está entre aspas
        char *inicio_aspas = strchr(linha + strlen(id_str) + 1, '"');
        if (inicio_aspas) {
            char *fim_aspas = strstr(inicio_aspas + 1, "\",");
            if (fim_aspas) {
                // Extrair o título completo entre aspas
                *fim_aspas = '\0';
                titulo = inicio_aspas + 1;
                // Pular a vírgula após as aspas e pegar os gêneros
                generos = fim_aspas + 2; // Pular "\","
            }
        } else {
            // Caso o título não tenha aspas, dividir normalmente
            titulo = strtok(NULL, ",");
            generos = strtok(NULL, ",");
        }

        // Remover o caractere de nova linha dos gêneros
        if (generos) {
            generos[strcspn(generos, "\n")] = '\0';
        }

        // Armazenar os dados na lista
        lista->vet[lista->tamanho].movieID = atoi(id_str); // Converter ID para inteiro
        lista->vet[lista->tamanho].ano = extrair_ano(titulo); // Extrair o ano
        if (titulo) {
            strncpy(lista->vet[lista->tamanho].movieTitle, titulo, sizeof(lista->vet[lista->tamanho].movieTitle) - 1);
            lista->vet[lista->tamanho].movieTitle[sizeof(lista->vet[lista->tamanho].movieTitle) - 1] = '\0';
        }
        if (generos) {
            strncpy(lista->vet[lista->tamanho].genres, generos, sizeof(lista->vet[lista->tamanho].genres) - 1);
            lista->vet[lista->tamanho].genres[sizeof(lista->vet[lista->tamanho].genres) - 1] = '\0';
        }

        lista->tamanho++;
    }
    fclose(arquivo);
}

void calcular_avaliacoes(tipo_lista *lista) {
    FILE *arquivo = fopen("ratings.csv", "r");
    if (!arquivo) {
        printf("Erro ao abrir o arquivo de avaliações.\n");
        return;
    }

    char linha[1024];
    fgets(linha, sizeof(linha), arquivo); // Ignorar o cabeçalho

    while (fgets(linha, sizeof(linha), arquivo)) {
        char *id_str = strtok(linha, ",");
        char *movie_id_str = strtok(NULL, ",");
        char *rating_str = strtok(NULL, ",");

        if (movie_id_str && rating_str) {
            int movieID = atoi(movie_id_str);
            float rating = atof(rating_str);

            // Procurar o filme na lista e atualizar a média
            for (int i = 0; i < lista->tamanho; i++) {
                if (lista->vet[i].movieID == movieID) {
                    // Atualizar a média incrementalmente
                    if (lista->vet[i].avaliacao == 0) {
                        lista->vet[i].avaliacao = rating;
                    } else {
                        lista->vet[i].avaliacao = (lista->vet[i].avaliacao + rating) / 2.0;
                    }
                    break;
                }
            }
        }
    }

    fclose(arquivo);
}

void processar_avaliacoes(hash_table *tabela, const char *arquivo_avaliacoes) {
    FILE *arquivo = fopen(arquivo_avaliacoes, "r");
    if (!arquivo) {
        printf("Erro ao abrir o arquivo de avaliações.\n");
        return;
    }

    char linha[1024];
    fgets(linha, sizeof(linha), arquivo); // Ignorar o cabeçalho

    while (fgets(linha, sizeof(linha), arquivo)) {
        char *user_id_str = strtok(linha, ",");
        char *movie_id_str = strtok(NULL, ",");
        char *rating_str = strtok(NULL, ",");

        if (movie_id_str && rating_str) {
            int movieID = atoi(movie_id_str);
            float rating = atof(rating_str);

            // Inserir ou atualizar na tabela hash
            inserir_ou_atualizar(tabela, movieID, rating);
        }
    }

    fclose(arquivo);
}

void calcular_medias(hash_table *tabela, tipo_lista *lista) {
    for (int i = 0; i < lista->tamanho; i++) {
        hash_entry *entry = buscar(tabela, lista->vet[i].movieID);
        if (entry != NULL) {
            lista->vet[i].avaliacao = entry->soma_avaliacoes / entry->num_avaliacoes;
        }
    }
}

int extrair_ano(const char *titulo) {
    const char *inicio = strrchr(titulo, '('); // Localiza o último '('
    const char *fim = strrchr(titulo, ')');   // Localiza o último ')'

    if (inicio && fim && fim > inicio) {
        char ano_str[5];
        strncpy(ano_str, inicio + 1, 4); // Copia os 4 caracteres do ano
        ano_str[4] = '\0';              // Garante a terminação da string

        // Verifica se os 4 caracteres são dígitos
        for (int i = 0; i < 4; i++) {
            if (!isdigit(ano_str[i])) {
                return 0; // Retorna 0 se não for um ano válido
            }
        }

        return atoi(ano_str); // Converte para inteiro e retorna
    }

    return 0; // Retorna 0 se não encontrar um ano válido
}

void shell_sort(tipo_dados *vet, int tamanho, int (*comparar)(const void *, const void *)) {
    for (int gap = tamanho / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < tamanho; i++) {
            tipo_dados temp = vet[i];
            int j;
            for (j = i; j >= gap && comparar(&vet[j - gap], &temp) > 0; j -= gap) {
                vet[j] = vet[j - gap];
            }
            vet[j] = temp;
        }
    }
}

void merge_sort(tipo_dados *vet, int left, int right, int (*comparar)(const void *, const void *)) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        merge_sort(vet, left, mid, comparar);
        merge_sort(vet, mid + 1, right, comparar);
        merge(vet, left, mid, right, comparar);
    }
}

void merge(tipo_dados *vet, int left, int mid, int right, int (*comparar)(const void *, const void *)) {
    int n1 = mid - left + 1;
    int n2 = right - mid;

    tipo_dados *L = malloc(n1 * sizeof(tipo_dados));
    tipo_dados *R = malloc(n2 * sizeof(tipo_dados));

    for (int i = 0; i < n1; i++) L[i] = vet[left + i];
    for (int j = 0; j < n2; j++) R[j] = vet[mid + 1 + j];

    int i = 0, j = 0, k = left;
    while (i < n1 && j < n2) {
        if (comparar(&L[i], &R[j]) <= 0) {
            vet[k] = L[i];
            i++;
        } else {
            vet[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        vet[k] = L[i];
        i++;
        k++;
    }

    while (j < n2) {
        vet[k] = R[j];
        j++;
        k++;
    }

    free(L);
    free(R);
}

void quick_sort(tipo_dados *vet, int low, int high, int (*comparar)(const void *, const void *)) {
    if (low < high) {
        int pivot = partition(vet, low, high, comparar);
        quick_sort(vet, low, pivot - 1, comparar);
        quick_sort(vet, pivot + 1, high, comparar);
    }
}

int partition(tipo_dados *vet, int low, int high, int (*comparar)(const void *, const void *)) {
    tipo_dados pivot = vet[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        if (comparar(&vet[j], &pivot) < 0) {
            i++;
            tipo_dados temp = vet[i];
            vet[i] = vet[j];
            vet[j] = temp;
        }
    }
    tipo_dados temp = vet[i + 1];
    vet[i + 1] = vet[high];
    vet[high] = temp;

    return i + 1;
}

// Comparar por título
int comparar_por_titulo(const void *a, const void *b) {
    tipo_dados *dado1 = (tipo_dados *)a;
    tipo_dados *dado2 = (tipo_dados *)b;
    return strcmp(dado1->movieTitle, dado2->movieTitle);
}

int remover_filmes_sem_ano(tipo_lista *lista) {
    int novo_tamanho = 0;
    int removidos = 0;

    for (int i = 0; i < lista->tamanho; i++) {
        if (lista->vet[i].ano > 0) {
            lista->vet[novo_tamanho++] = lista->vet[i];
        } else {
            removidos++;
        }
    }

    lista->tamanho = novo_tamanho;
    return removidos; // Retorna a quantidade de filmes removidos
}
// Comparar por avaliação
int comparar_por_avaliacao(const void *a, const void *b) {
    tipo_dados *dado1 = (tipo_dados *)a;
    tipo_dados *dado2 = (tipo_dados *)b;

    // Filmes sem avaliação (avaliacao == 0) são considerados "maiores" e vão para o final
    if (dado1->avaliacao == 0 && dado2->avaliacao != 0) return 1;
    if (dado2->avaliacao == 0 && dado1->avaliacao != 0) return -1;

    // Comparar normalmente se ambos os filmes têm avaliação
    if (dado1->avaliacao < dado2->avaliacao) return -1;
    if (dado1->avaliacao > dado2->avaliacao) return 1;
    return 0;
}
int comparar_por_ano(const void *a, const void *b) {
    tipo_dados *dado1 = (tipo_dados *)a;
    tipo_dados *dado2 = (tipo_dados *)b;

    // Filmes sem ano (ano == 0) são considerados "maiores" e vão para o final
    if (dado1->ano == 0 && dado2->ano != 0) return 1;
    if (dado2->ano == 0 && dado1->ano != 0) return -1;

    // Comparar normalmente se ambos os filmes têm ano
    return dado1->ano - dado2->ano;
}

int remover_filmes_sem_avaliacao(tipo_lista *lista) {
    int novo_tamanho = 0;
    int removidos = 0;

    for (int i = 0; i < lista->tamanho; i++) {
        if (lista->vet[i].avaliacao > 0) {
            lista->vet[novo_tamanho++] = lista->vet[i];
        } else {
            removidos++;
        }
    }

    lista->tamanho = novo_tamanho;
    return removidos; // Retorna a quantidade de filmes removidos
}