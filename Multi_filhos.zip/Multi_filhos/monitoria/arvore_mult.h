#ifndef __ARVORE_MULT_H__
#define __ARVORE_MULT_H__

#include <stdio.h>
#include <stdlib.h>

#define MAX 3

struct no_arvore_mult
{
    int chave;
    char letra;
};
typedef struct no_arvore_mult tipo_no;

struct est_arv
{
    tipo_no* vet[MAX];
    int contador;
    struct est_arv* ponteiros[MAX + 1];
};
typedef struct est_arv tipo_arvore;

//Prototipo das funções
tipo_no* aloca_no(int, char);
tipo_arvore* inicializar_arvore();
int encontrar_filho(tipo_arvore*, int);
void insere(tipo_arvore**, int, char);
void imprime_pre_ordem(tipo_arvore* arv);
void imprime_em_ordem(tipo_arvore* arv);
void imprime_pos_ordem(tipo_arvore* arv);
int total_nos(tipo_arvore* arv);
int total_folhas(tipo_arvore* arv);
char busca_dado(tipo_arvore* arv, int chave);
tipo_no* busca_no(tipo_arvore* arv, int chave);
void verifica_folha(tipo_arvore* arv, int chave);
int altura_arvore(tipo_arvore* arv);
void imprime_nivel(tipo_arvore* arv, int nivel_atual, int);
void imprime_por_nivel(tipo_arvore* arv);
int contabiliza_nos_por_nivel(tipo_arvore* arv, int nivel);
void imprime_rota_ate_valor(tipo_arvore* arv, int chave);
char busca_maior_valor(tipo_arvore* arv);
char busca_menor_valor(tipo_arvore* arv);
#endif
