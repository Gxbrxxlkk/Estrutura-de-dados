#include "arvore_mult.h"

tipo_no* aloca_no(int chave, char letra) {
    tipo_no* novo_no = (tipo_no*)malloc(sizeof(tipo_no));
    if (novo_no == NULL) {
        printf("Erro ao alocar memória para o nó.\n");
        exit(1);
    }
    novo_no->chave = chave;
    novo_no->letra = letra;
    return novo_no;
}

tipo_arvore* inicializar_arvore() {
    tipo_arvore* nova_arvore = (tipo_arvore*)malloc(sizeof(tipo_arvore));
    if (nova_arvore == NULL) {
        printf("Erro ao alocar memória para a árvore.\n");
        exit(1);
    }

    nova_arvore->contador = 0;

    for (int i = 0; i < MAX; i++) {
        nova_arvore->vet[i] = NULL;
    }

    for (int i = 0; i <= MAX; i++) {
        nova_arvore->ponteiros[i] = NULL;
    }
    return nova_arvore;
}

int encontrar_filho(tipo_arvore* no, int chave) {
    int i = 0;
    while (i < no->contador && chave > no->vet[i]->chave) {
        i++;
    }
    return i;
}


void insere(tipo_arvore** arv, int chave, char letra) {

    //Inicializa a arvore se ela estiver vazia (não precisa inicializa na main)
    if (*arv == NULL) *arv = inicializar_arvore();
    
    tipo_arvore* no_atual = *arv;

    // Caso o no atual ainda tenha espaço para mais elementos
    if (no_atual->contador < MAX) {
        int i = no_atual->contador - 1;
        while (i >= 0 && chave < no_atual->vet[i]->chave) {
            no_atual->vet[i + 1] = no_atual->vet[i]; 
            i--;
        }

        // Insere o novo elemento na posição correta
        no_atual->vet[i + 1] = aloca_no(chave, letra);
        no_atual->contador++;
    } else {
        // Caso o nó esteja cheio, encontra o filho para descer
        int pos = encontrar_filho(no_atual, chave);

        insere(&no_atual->ponteiros[pos], chave, letra);
    }
}

void imprime_pre_ordem(tipo_arvore* arv) {
    if (arv == NULL) return;

    for (int i = 0; i < arv->contador; i++) {
        printf("(%d, %c) ", arv->vet[i]->chave, arv->vet[i]->letra);
    }

    for (int i = 0; i <= arv->contador; i++) {
        imprime_pre_ordem(arv->ponteiros[i]);
    }
}

void imprime_em_ordem(tipo_arvore* arv) {
    if (arv == NULL) return;

    for (int i = 0; i < arv->contador; i++) {
        
        imprime_em_ordem(arv->ponteiros[i]);

        printf("(%d, %c) ", arv->vet[i]->chave, arv->vet[i]->letra);
    }

    imprime_em_ordem(arv->ponteiros[arv->contador]);
}

void imprime_pos_ordem(tipo_arvore* arv) {
    if (arv == NULL) return;

    for (int i = 0; i <= arv->contador; i++) {
        imprime_pos_ordem(arv->ponteiros[i]);
    }

    for (int i = 0; i < arv->contador; i++) {
        printf("(%d, %c) ", arv->vet[i]->chave, arv->vet[i]->letra);
    }
}

int total_nos(tipo_arvore* arv) {
    if (arv == NULL) return 0;

    int total = 0;
    for (int i = 0; i < arv->contador; i++) {
        total++;
    }

    for (int i = 0; i <= arv->contador; i++) {
        total += total_nos(arv->ponteiros[i]);
    }

    return total;
}

int total_folhas(tipo_arvore* arv) {
    if (arv == NULL) return 0;

    int eh_folha = 1;
    for (int i = 0; i <= arv->contador; i++) {
        if (arv->ponteiros[i] != NULL) {
            eh_folha = 0;
            break;
        }
    }

    if (eh_folha) return 1; 
    int total = 0;
    for (int i = 0; i <= arv->contador; i++) {
        total += total_folhas(arv->ponteiros[i]);
    }

    return total;
}

char busca_dado(tipo_arvore* arv, int chave) {
    if (arv == NULL) return '\0';

    for (int i = 0; i < arv->contador; i++) {
        if (arv->vet[i]->chave == chave) {
            return arv->vet[i]->letra; 
        }
    }

    for (int i = 0; i <= arv->contador; i++) {
        char resultado = busca_dado(arv->ponteiros[i], chave);
        if (resultado != '\0') {
            return resultado; 
        }
    }

    return '\0'; 
}

tipo_no* busca_no(tipo_arvore* arv, int chave) {
    if (arv == NULL) return NULL;


    for (int i = 0; i < arv->contador; i++) {
        if (arv->vet[i]->chave == chave) {
            return arv->vet[i]; 
        }
    }

    for (int i = 0; i <= arv->contador; i++) {
        tipo_no* resultado = busca_no(arv->ponteiros[i], chave);
        if (resultado != NULL) {
            return resultado; 
        }
    }

    return NULL; 
}

void verifica_folha(tipo_arvore* arv, int chave) {
    if (arv == NULL) return; 

    for (int i = 0; i < arv->contador; i++) {
        if (arv->vet[i]->chave == chave) {
            if (arv->ponteiros[i] == NULL) {
                printf("O no com chave %d e uma folha.\n", chave);
            } else {
                printf("O no com chave %d nao e uma folha.\n", chave);
            }
            return;
        }
    }

    int pos = encontrar_filho(arv, chave);
    verifica_folha(arv->ponteiros[pos], chave);
}

int altura_arvore(tipo_arvore* arv) {
    if (arv == NULL) return 0; 

    int altura_max = 0;
    for (int i = 0; i <= arv->contador; i++) {
        int altura_atual = altura_arvore(arv->ponteiros[i]);
        if (altura_atual > altura_max) {
            altura_max = altura_atual;
        }
    }

    return altura_max + 1; 
}

void imprime_nivel(tipo_arvore* arv, int nivel_atual, int nivel_desejado) {
    if (arv == NULL) return;

    if (nivel_atual == nivel_desejado) {
        printf("[");
        for (int i = 0; i < arv->contador; i++) {
            printf("(%d, %c)", arv->vet[i]->chave, arv->vet[i]->letra);
            if (i < arv->contador - 1) printf(", ");
        }
        printf("] ");
        return;
    }

    for (int i = 0; i <= arv->contador; i++) {
        imprime_nivel(arv->ponteiros[i], nivel_atual + 1, nivel_desejado);
    }
}

void imprime_por_nivel(tipo_arvore* arv) {
    if (arv == NULL) return;

    int altura = altura_arvore(arv);

    for (int i = 0; i < altura; i++) {
        printf("\nNível %d: ", i);
        imprime_nivel(arv, 0, i);
    }
    printf("\n");
}

int contabiliza_nos_por_nivel(tipo_arvore* arv, int nivel) {
    if (arv == NULL) return 0;

    if (nivel == 0) {
        return arv->contador; 
    }

    int total = 0;
    for (int i = 0; i <= arv->contador; i++) {
        total += contabiliza_nos_por_nivel(arv->ponteiros[i], nivel - 1);
    }

    return total;
}

void imprime_rota_ate_valor(tipo_arvore* arv, int chave) {
    if (arv == NULL) return; 

    for (int i = 0; i < arv->contador; i++) {
        if (arv->vet[i]->chave == chave) {
            printf("Rota ate o no com chave %d: ", chave);
            for (int j = 0; j <= i; j++) {
                printf("(%d, %c) ", arv->vet[j]->chave, arv->vet[j]->letra);
            }
            printf("\n");
            return;
        }
    }

    int pos = encontrar_filho(arv, chave);
    imprime_rota_ate_valor(arv->ponteiros[pos], chave);
}

char busca_maior_valor(tipo_arvore* arv) {
    if (arv == NULL) return '\0'; 

    tipo_arvore* atual = arv;

    while (atual->ponteiros[atual->contador] != NULL) {
        atual = atual->ponteiros[atual->contador];
    }

    return atual->vet[atual->contador - 1]->letra; 
}

char busca_menor_valor(tipo_arvore* arv) {
    if (arv == NULL) return '\0';

    char menor = '\0';

    for (int i = 0; i < arv->contador; i++) {
        if (menor == '\0' || arv->vet[i]->letra < menor) {
            menor = arv->vet[i]->letra;
        }
    }

    for (int i = 0; i <= arv->contador; i++) {
        char menor_filho = busca_menor_valor(arv->ponteiros[i]);
        if (menor_filho != '\0' && (menor == '\0' || menor_filho < menor)) {
            menor = menor_filho;
        }
    }

    return menor;
}