#include "arvore_mult.h"

tipo_no* aloca_no(int chave, char letra) {
    tipo_no* novo_no = (tipo_no*)malloc(sizeof(tipo_no));
    if (novo_no != NULL){
        
        novo_no->chave = chave;
        novo_no->letra = letra;
    }
    return novo_no;
}

tipo_arvore* inicializar_arvore() {
    tipo_arvore* novo = (tipo_arvore*)malloc(sizeof(tipo_arvore));
    if (novo != NULL) {
        novo->contador = 0;
        for (int i = 0; i < MAX; i++) {
            novo->vet[i] = NULL;
        }
        for (int i = 0; i < MAX + 1; i++) {
            novo->ponteiros[i] = NULL;
        }
    }
    return novo;
}
int encontrar_filho(tipo_arvore* no, char letra) {
    int i = 0;
    while (i < no->contador && letra > no->vet[i]->letra) {
        i++;
    }
    return i;
}

//lembrar de inicializar a arvore na main
void insere(tipo_arvore** arv, int chave, char letra) {
    tipo_no* novo_no = aloca_no(chave, letra);

    if (*arv == NULL) {
        *arv = inicializar_arvore();
        (*arv)->vet[0] = novo_no;
        (*arv)->contador = 1;
        return;
    }

    // Se há espaço no nó, insere ordenado
    if ((*arv)->contador < MAX) {
        int i = (*arv)->contador - 1;
        while (i >= 0 && letra < (*arv)->vet[i]->letra) {
            (*arv)->vet[i + 1] = (*arv)->vet[i];
            i--;
        }
        (*arv)->vet[i + 1] = novo_no;
        (*arv)->contador++;
        return;
    }

    // Nó cheio: desce para o filho correto
    int pos = encontrar_filho(*arv, letra);
    insere(&((*arv)->ponteiros[pos]), chave, letra);
}
void imprimir(tipo_arvore* arv, int nivel) {
    if (arv == NULL) return;

    // Indenta de acordo com o nível
    for (int i = 0; i < nivel; i++) printf("  ");

    printf("[");
    for (int i = 0; i < arv->contador; i++) {
        printf("(%d, %c)", arv->vet[i]->chave, arv->vet[i]->letra);
        if (i < arv->contador - 1) printf(", ");
    }
    printf("]\n");

    for (int i = 0; i <= arv->contador; i++) {
        imprimir(arv->ponteiros[i], nivel + 1);
    }
}
