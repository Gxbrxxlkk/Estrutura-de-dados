#include "arvore_mult.h"

tipo_filho* aloca_no(int chave, char letra) {
    tipo_filho* novo_no = (tipo_filho*)malloc(sizeof(tipo_filho));
    if (novo_no == NULL) exit(1);
    
    novo_no->chave = chave;
    novo_no->letra = letra;
    return novo_no;
}

void insert_sort(tipo_arvore*vet[], int n) {
    for (int i = 0; i < n; i++)
    {
        int chave = vet[i];
        int j = i - 1;

        while (j>= 0 && vet[j] > chave)
        {
            vet[j + 1] = vet[j];
            j--;
        }
        vet[j + 1] = chave;
    }
}


//lembrar de inicializar o contador como 0 na main
void inserir(tipo_arvore** arv, int chave, char letra) {
    tipo_filho* novo_no = aloca_no(chave, letra);
    if (*arv == NULL)
    {
        *arv = novo_no;
        return;
    }
    if ((*arv)->contador == 1)
    {
        (*arv)->vet[(*arv)->contador] = novo_no;
        return;
    }
    if ((*arv)->contador < MAX)
    {
        (*arv)->vet[(*arv)->contador++] = novo_no;
        
        insert_sort((*arv)->vet, (*arv)->contador);
        return;
    }
    if ((*arv)->contador >= MAX)
    {
        /* code */
    }
    

}