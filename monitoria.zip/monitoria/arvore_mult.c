#include "arvore_mult.h"

tipo_no* aloca_no(int chave, char letra) {
    tipo_no* novo_no = (tipo_no*)malloc(sizeof(tipo_no));
    if (novo_no != NULL){
        
        novo_no->chave = chave;
        novo_no->letra = letra;
    }
    return novo_no;
}
tipo_arvore* inicializar_arvore() {
    tipo_arvore* novo = (tipo_arvore*)malloc(sizeof(tipo_arvore));
    if (novo != NULL) {
        novo->contador = 0;
        for (int i = 0; i < MAX; i++) {
            novo->vet[i] = NULL;
        }
        for (int i = 0; i < MAX + 1; i++) {
            novo->ponteiros[i] = NULL;
        }
    }
    return novo;
}

//lembrar de inicializar a arvore na main
void insere(tipo_arvore** arv, int chave, char letra) {
    tipo_no* novo_no = aloca_no(chave, letra);
    int i = (*arv)->contador;

    if (i<MAX)
    {
        (*arv)->vet[i] = novo_no;
        i++;
        return;
    } 
    
    do
    {
        if ((*arv)->vet[i]->letra > letra)
        {
            (*arv)->ponteiros[i]->contador = novo_no;
        }
        
    } while (i>= 0 && i<MAX);
    
    
}