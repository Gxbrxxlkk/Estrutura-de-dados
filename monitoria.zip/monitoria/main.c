#include "arvore_mult.h"

int main() {
    tipo_arvore* raiz = NULL;

    insere(&raiz, 10, 'M');
    insere(&raiz, 20, 'C');
    insere(&raiz, 30, 'R');
    insere(&raiz, 5, 'A');
    insere(&raiz, 25, 'P');
    insere(&raiz, 40, 'Z');

    printf("Árvore:\n");
    imprimir(raiz, 0);

    return 0;
}