#ifndef __ARVORE_MULT_H__
#define __ARVORE_MULT_H__
#include <stdio.h>
#include <stdlib.h>

#define MAX 3

struct arvore_mult
{
    int chave;
    char letra;
};
typedef struct arvore_mult tipo_filho;

struct est_arv
{
    tipo_filho* vet[MAX];
    int contador;
    struct est_arv* ponteiros[MAX + 1];
};
typedef struct est_arv tipo_arvore;

//Prototipo das funções
tipo_filho* aloca_no(int, char);
void inserir(tipo_filho**, int, char);
void insert_sort(tipo_arvore*[], int);

#endif