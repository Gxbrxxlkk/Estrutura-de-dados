#ifndef __ARVORE_MULT_H__
#define __ARVORE_MULT_H__
#include <stdio.h>
#include <stdlib.h>

#define MAX 3

struct arvore_mult
{
    int chave;
    char letra;
};
typedef struct arvore_mult tipo_no;

struct est_arv
{
    tipo_no* vet[MAX];
    int contador;
    struct est_arv* ponteiros[MAX + 1];
};
typedef struct est_arv tipo_arvore;

//Prototipo das funções
tipo_no* aloca_no(int, char);
tipo_arvore* inicializar_arvore();
int encontrar_filho(tipo_arvore*, char);
void insere(tipo_arvore**, int, char);
void imprimir(tipo_arvore*,int);

#endif