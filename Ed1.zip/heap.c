#include <stdio.h>
#define TAM 100
typedef struct heap
{
    int vet[TAM];
    int tamanho;
} tipo_heap;

void inserir_heap(tipo_heap*, int);
void ordenar_heap_max(tipo_heap*, int);
void ordernar_heap(tipo_heap* hp);
void imprimir_heap(tipo_heap*);
int removeraiz(tipo_heap*);
void desce_heap(tipo_heap*, int);
int filhoesq(int);
int filhodireito(int);

void imprimir_heap(tipo_heap* hp) {
    for (size_t i = 0; i < hp->tamanho; i++) {
        printf("%d -> ", hp->vet[i]);
    }
    printf("\n");
}
int filhoesq(int i) {
    return 2*i + 1;
}
int filhodireito(int i) {
    return 2*i + 2;
}

void inserir_heap(tipo_heap* hp, int valor) {
    if (hp->tamanho == TAM) return;  // Verifica se o heap está cheio
    
    hp->vet[hp->tamanho] = valor;  // Insere o valor no final
    hp->tamanho++;                 // Incrementa o tamanho
    ordenar_heap_max(hp, hp->tamanho - 1);  // Organiza o heap após a inserção
}

void ordernar_heap(tipo_heap* hp) {
    int index = (hp->tamanho - 1);
    
    ordenar_heap_max(hp, index);
}
void ordenar_heap_max(tipo_heap* hp, int index) {
    int pai = (index - 1) / 2;  // Índice do pai

    // Enquanto o índice for maior que 0 e o valor do filho for maior que o pai
    while (index > 0 && hp->vet[index] > hp->vet[pai]) {
        // Troca os valores
        int temp = hp->vet[index];
        hp->vet[index] = hp->vet[pai];
        hp->vet[pai] = temp;

        // Atualiza o índice para o pai
        index = pai;
        pai = (index - 1) / 2;  // Calcula o novo índice do pai
    }
}

int removeraiz(tipo_heap* hp) {
    if (hp->tamanho == 0) return -1;  
    int valor = hp->vet[0];  
    hp->vet[0] = hp->vet[hp->tamanho - 1];  
    hp->tamanho--;  

    desce_heap(hp, 0);  
    return valor;
}

void desce_heap(tipo_heap* hp, int i) {
    int esq = filhoesq(i);     
    int dir = filhodireito(i); 
    int maior = i;             // Inicializa o maior como o índice atual

    if (esq < hp->tamanho && hp->vet[esq] > hp->vet[maior]) {
        maior = esq;
    }

    if (dir < hp->tamanho && hp->vet[dir] > hp->vet[maior]) {
        maior = dir;
    }

    if (maior != i) {
        int temp = hp->vet[i];
        hp->vet[i] = hp->vet[maior];
        hp->vet[maior] = temp;

        desce_heap(hp, maior);
    }
}



int main() {

    tipo_heap meu_heap;
    meu_heap.tamanho = 0;
    inserir_heap(&meu_heap, 4);
    inserir_heap(&meu_heap, 8);
    inserir_heap(&meu_heap, 2);
    inserir_heap(&meu_heap, 1);    
    inserir_heap(&meu_heap, 7);    
    inserir_heap(&meu_heap, 3);

    printf("Heap antes da remoção da raiz:\n");
    imprimir_heap(&meu_heap);

    // Removendo a raiz do heap
    int valor_removido = removeraiz(&meu_heap);
    printf("\nValor removido (raiz): %d\n", valor_removido);

    // Imprimindo o heap após a remoção
    printf("Heap após a remoção da raiz:\n");
    imprimir_heap(&meu_heap);


    return 0;
}