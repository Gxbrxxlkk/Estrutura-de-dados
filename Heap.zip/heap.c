#include "heap.h"

void imprimir_heap(tipo_heap* hp) {
    for (size_t i = 0; i < (hp->tamanho -1); i++) {
        printf("%d -> ", hp->vet[i]);
    }
    printf("\n");
}

int ind_filho_esquerdo(int i) {
    return 2*i + 1;
}

int ind_filho_direito(int i) {
    return 2*i + 2;
}

void inserir_heap(tipo_heap* hp, int valor) {
    if (hp->tamanho == TAM) return;  // Verifica se o heap está cheio
    
    hp->vet[hp->tamanho] = valor;  // Insere o valor no final
    hp->tamanho++;                 // Incrementa o tamanho
    sobe_heap(hp, hp->tamanho - 1);  // Organiza o heap após a inserção
}

void sobe_heap(tipo_heap* hp, int index) {
    int pai = (index - 1) / 2;  // Índice do pai

    // Enquanto o índice for maior que 0 e o valor do filho for maior que o pai
    while (index > 0 && hp->vet[index] < hp->vet[pai]) {
        // Troca os valores
        int temp = hp->vet[index];
        hp->vet[index] = hp->vet[pai];
        hp->vet[pai] = temp;

        // Atualiza o índice para o pai
        index = pai;
        pai = (index - 1) / 2;  // Calcula o novo índice do pai
    }
}

int remove_raiz(tipo_heap* hp) {
    if (hp->tamanho == 0) return -1;  
    int valor = hp->vet[0];  
    hp->vet[0] = hp->vet[hp->tamanho - 1];  
    hp->tamanho--;  

    desce_heap(hp, 0);  
    return valor;
}

void desce_heap(tipo_heap* hp, int i) {
    int esq = ind_filho_esquerdo(i);     
    int dir = ind_filho_direito(i); 
    int maior = i;             // Inicializa o maior como o índice atual

    if (esq < hp->tamanho && hp->vet[esq] < hp->vet[maior]) {
        maior = esq;
    }

    if (dir < hp->tamanho && hp->vet[dir] < hp->vet[maior]) {
        maior = dir;
    }

    if (maior != i) {
        int temp = hp->vet[i];
        hp->vet[i] = hp->vet[maior];
        hp->vet[maior] = temp;

        desce_heap(hp, maior);
    }
}