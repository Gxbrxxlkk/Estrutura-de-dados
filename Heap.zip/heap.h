#ifndef __HEAP_H__
#define __HEAP_H__

#include <stdlib.h>
#include <stdio.h>
#define TAM 100
typedef struct heap
{
    int vet[TAM];
    int tamanho;
} tipo_heap;

void inserir_heap(tipo_heap*, int);
void sobe_heap(tipo_heap*, int);
void imprimir_heap(tipo_heap*);
int remove_raiz(tipo_heap*);
void desce_heap(tipo_heap*, int);
int ind_filho_esquerdo(int);
int ind_filho_direito(int);


#endif