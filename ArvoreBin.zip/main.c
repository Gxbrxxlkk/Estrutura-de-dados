#include "arvore_bin.h"

int main() {
    srand(time(NULL));

    tipo_arvore* minha_arvore = NULL;

    for (int i = 0; i < 10; i++) {
        char c = 'A' + (rand() % 26);
        int v = rand() % 100;
        inserir(&minha_arvore, c, v);
    }

    printf("Pré-ordem: ");
    imprimir_preordem(minha_arvore);
    printf("\n");

    printf("Em ordem: ");
    imprimir_ordem(minha_arvore);
    printf("\n");

    printf("Pós-ordem: ");
    imprimir_posordem(minha_arvore);
    printf("\n");

    printf("Total de nós: %d\n", contar_no_total(minha_arvore));
    printf("Total de folhas: %d\n", contar_no_folha(minha_arvore));
    printf("Altura da árvore: %d\n", calcula_altura_arv(minha_arvore));

    int nivel = 2;
    printf("Nós no nível %d: %d\n", nivel, conta_no_nivel(minha_arvore, nivel));

    int chave_busca = 40;
    tipo_arvore* encontrado = buscar_no(minha_arvore, chave_busca);
    if (encontrado != NULL)
        printf("Nó com chave %d encontrado: %c\n", chave_busca, encontrado->valor);
    else
        printf("Nó com chave %d não encontrado.\n", chave_busca);

    if (verifica_no_folha(minha_arvore, chave_busca))
        printf("Nó com chave %d é uma folha.\n", chave_busca);
    else
        printf("Nó com chave %d não é uma folha ou não existe.\n", chave_busca);

    printf("\nImpressão por nível:\n");
    imprimir_por_nivel(minha_arvore);

    printf("\nCaminho até a chave %d:\n", chave_busca);
    imprime_caminho(minha_arvore, chave_busca);
    printf("\n");

    printf("\nRemovendo a raiz...\n");
    tipo_arvore* no_removido = remove_no(&minha_arvore, minha_arvore->chave);
    if (no_removido != NULL) {
        printf("Nó removido: [%d]: %c\n", no_removido->chave, no_removido->valor);
        free(no_removido);
    } else {
        printf("Raiz não foi removida.\n");
    }

    printf("\nNova impressão em ordem após remover a raiz: ");
    imprimir_ordem(minha_arvore);
    printf("\n");

    return 0;
}
