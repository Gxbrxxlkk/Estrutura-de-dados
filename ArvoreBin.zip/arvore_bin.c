#include "arvore_bin.h"

char letra_aleatoria() {
    return 'A' + (rand() % 26);
}

tipo_arvore* aloca_no(char val, int chave) {
    tipo_arvore* novo_no = (tipo_arvore*)malloc(sizeof(tipo_arvore));

    if (novo_no == NULL) {
        exit(1);
    }
    novo_no->dir = NULL;
    novo_no->esq = NULL;
    novo_no->valor = val;
    novo_no->chave = chave;
    return novo_no;
}

void inserir(tipo_arvore** arv, char valor, int chav) {
    if (*arv == NULL)
    {
        *arv = aloca_no(valor, chav);
    } else {
        if (valor < (*arv)->valor)
        {
            inserir(&(*arv)->esq, valor, chav);
        } else {
            inserir(&(*arv)->dir, valor, chav);
        }
    }
}

void imprimir_preordem(tipo_arvore* arv) {
    if (arv != NULL) {
        printf("[%d]: ", arv->chave);
        printf("%c ", arv->valor);
        imprimir_preordem(arv->esq);
        imprimir_preordem(arv->dir);
    }
}

void imprimir_ordem(tipo_arvore* arv) {
    if (arv != NULL) {
        imprimir_ordem(arv->esq);
        printf("[%d]: ", arv->chave);
        printf("%c ", arv->valor);
        imprimir_ordem(arv->dir);
    }
}

void imprimir_posordem(tipo_arvore* arv) {
    if (arv != NULL)
    {
        imprimir_posordem(arv->esq);
        imprimir_posordem(arv->dir);
        printf("[%d]: ", arv->chave);
        printf("%c ", arv->valor);
    }   
}

int contar_no_total(tipo_arvore* arv) {
    if (arv == NULL) {
        return 0;
    } else {
        return 1 + contar_no_total(arv->esq) + contar_no_total(arv->dir);
    }
}

int contar_no_folha(tipo_arvore* arv) {
    if (arv == NULL) {
        return 0;
    }

    if (arv->esq == NULL && arv->dir == NULL)
    {
        return 1 + contar_no_folha(arv->esq) + contar_no_folha(arv->dir);
    } else {
        return contar_no_folha(arv->esq) + contar_no_folha(arv->dir);
    }
}

tipo_arvore* buscar_no(tipo_arvore* arv, int chave) {
    if (arv == NULL)
        return NULL;

    if (arv->chave == chave)
    {
        return arv;
    }
    if (chave < arv->chave)
    {
        return buscar_no(arv->esq, chave);
    } else {
        return buscar_no(arv->dir, chave);
    }
}

int verifica_no_folha(tipo_arvore* arv, int chave) {
    if (arv == NULL)
    {
        return 0;
    }
    if (chave == arv->chave) {

        if (arv->esq == NULL && arv->dir == NULL)   
        {
            return 1;
        } else return 0;
        
    } else {
        return verifica_no_folha(arv->esq, chave) + verifica_no_folha(arv->dir, chave);
    }
}

int calcula_altura_arv(tipo_arvore* arv) {
    if (arv == NULL)
    {
        return 0;
    } else {
        int alt_esq = calcula_altura_arv(arv->esq);
        int alt_dir = calcula_altura_arv(arv->dir);
        return 1 + (alt_esq > alt_dir ? alt_esq : alt_dir);
    }
}

int conta_no_nivel(tipo_arvore* arv, int nivel) {
    if (arv == NULL)
        return 0;
    if (nivel == 0) 
        return 1;

    return conta_no_nivel(arv->esq, nivel - 1) + conta_no_nivel(arv->dir, nivel - 1);
}

void imprimir_nivel(tipo_arvore* arv, int nivel) {
    if (arv == NULL)
        return;

    if (nivel == 0)
        printf("[%d]: %c ", arv->chave, arv->valor);
    else {
        imprimir_nivel(arv->esq, nivel - 1);
        imprimir_nivel(arv->dir, nivel - 1);
    }
}

void imprimir_por_nivel(tipo_arvore* arv) {
    int altura = calcula_altura_arv(arv);
    for (int i = 0; i < altura; i++) {
        printf("Nivel %d: ", i);
        imprimir_nivel(arv, i);
        printf("\n");
    }
}

int imprime_caminho(tipo_arvore* arv, int chave) {
    if (arv == NULL)
        return 0;

    printf("[%d]: %c ", arv->chave, arv->valor);

    if (arv->chave == chave)
        return 1;

    if (chave < arv->chave)
        return imprime_caminho(arv->esq, chave);
    else
        return imprime_caminho(arv->dir, chave);
}


tipo_arvore* remove_no(tipo_arvore** arv, int chave) {
    if (*arv == NULL) return NULL;

    tipo_arvore* removido = NULL;

    if (chave < (*arv)->chave) {
        removido = remove_no(&(*arv)->esq, chave);
    } else if (chave > (*arv)->chave) {
        removido = remove_no(&(*arv)->dir, chave);
    } else {
        removido = *arv;

        if ((*arv)->esq == NULL) {
            *arv = (*arv)->dir;
        } else if ((*arv)->dir == NULL) {
            *arv = (*arv)->esq;
        } else {
            // Dois filhos: encontrar o sucessor (menor da direita)
            tipo_arvore** substituto = &(*arv)->dir;
            while ((*substituto)->esq != NULL) {
                substituto = &(*substituto)->esq;
            }

            tipo_arvore* temp = *substituto;
            (*arv)->chave = temp->chave;
            (*arv)->valor = temp->valor;

            // Remover o sucessor recursivamente
            *substituto = temp->dir;
            removido = temp;
        }
    }

    return removido;
}

