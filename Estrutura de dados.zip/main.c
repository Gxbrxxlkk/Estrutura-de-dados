#include "arvore_bin.h"

int main() {
    srand(time(NULL));

    tipo_arvore* minha_arvore = NULL;

    for (int i = 0; i < 10; i++) {
        char c = 'A' + (rand() % 26);
        int v = rand() % 100;
        inserir(&minha_arvore, c, v);
    }
    
    printf("Pré-ordem: ");
    imprimir_preordem(minha_arvore);
    printf("\n");

    printf("Em ordem: ");
    imprimir_ordem(minha_arvore);
    printf("\n");

    printf("Pós-ordem: ");
    imprimir_posordem(minha_arvore);
    printf("\n");

    printf("Total de nós: %d\n", contar_no_total(minha_arvore));
    printf("Total de folhas: %d\n", contar_no_folha(minha_arvore));
    printf("Altura da árvore: %d\n", calcula_altura_arv(minha_arvore));

    int nivel = 2;
    printf("Nós no nível %d: %d\n", nivel, conta_no_nivel(minha_arvore, nivel));

    int chave_busca = 40;
    tipo_arvore* encontrado = buscar_no(minha_arvore, chave_busca);
    if (encontrado != NULL)
        printf("Nó com chave %d encontrado: %c\n", chave_busca, encontrado->valor);
    else
        printf("Nó com chave %d não encontrado.\n", chave_busca);

    if (verifica_no_folha(minha_arvore, chave_busca))
        printf("Nó com chave %d é uma folha.\n", chave_busca);
    else
        printf("Nó com chave %d não é uma folha ou não existe.\n", chave_busca);

    return 0;
}