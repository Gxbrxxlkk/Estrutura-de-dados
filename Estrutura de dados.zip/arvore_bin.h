#ifndef __ARVORE_BIN_H__
#define __ARVORE_BIN_H__

//Incluindo bibliotecas
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//estrutura da arvore binaria
struct arvore_bin
{
    struct arvore_bin* esq;
    struct arvore_bin* dir;
    int chave;
    char valor;
};
typedef struct arvore_bin tipo_arvore;

//prototipo das funções
char letra_aleatoria();
tipo_arvore* aloca_no(char, int);
void inserir(tipo_arvore**, char, int);
void imprimir_preordem(tipo_arvore*);
void imprimir_ordem(tipo_arvore*);
void imprimir_posordem(tipo_arvore*);
int contar_no_total(tipo_arvore*);
int contar_no_folha(tipo_arvore*);
tipo_arvore* buscar_no(tipo_arvore*, int);
int verifica_no_folha(tipo_arvore*, int);
int calcula_altura_arv(tipo_arvore*);
int conta_no_nivel(tipo_arvore*, int);
//falta imprimir a arvore por nivel e imprimir a rota

#endif //__ARVORE_BIN_H__