#include "arvore_mult.h"

int main()
{
    tipo_arvore *raiz = NULL;

    // Inserção de elementos
    insere(&raiz, 10, 'M');
    insere(&raiz, 20, 'C');
    insere(&raiz, 30, 'R');
    insere(&raiz, 5, 'A');
    insere(&raiz, 25, 'P');
    insere(&raiz, 40, 'Z');    
    insere(&raiz, 2, 'K');
    insere(&raiz, 34, 'J');
    insere(&raiz, 7, 'G');
    insere(&raiz, 22, 'V');
    insere(&raiz, 41, 'B');

    
    printf("\nImpressão Pré-Ordem:\n");
    imprime_pre_ordem(raiz);
    printf("\n");

    printf("\nImpressão Em Ordem:\n");
    imprime_em_ordem(raiz);
    printf("\n");

    printf("\nImpressão Pós-Ordem:\n");
    imprime_pos_ordem(raiz);
    printf("\n");

    
    printf("\nTotal de nós: %d\n", total_nos(raiz));
    printf("Total de folhas: %d\n", total_folhas(raiz));

    
    printf("Altura da árvore: %d\n", altura_arvore(raiz));

int chave_busca = 25;  //Chave inserida manualmente para as funcoes 

char letra = busca_dado(raiz, chave_busca);
if (letra != '\0') {
    printf("Letra associada a chave %d: %c\n", chave_busca, letra);
} else {
    printf("Chave %d não encontrada.\n", chave_busca);
}

tipo_no* no_encontrado = busca_no(raiz, chave_busca);
if (no_encontrado != NULL) {
    printf("Nó encontrado: (%d, %c)\n", no_encontrado->chave, no_encontrado->letra);
} else {
    printf("Nó com chave %d não encontrado.\n", chave_busca);
}


    verifica_folha(raiz, chave_busca);


    printf("Maior valor na árvore: %c\n", busca_maior_valor(raiz));
    printf("Menor valor na árvore: %c\n", busca_menor_valor(raiz));

    printf("\nImpressão por nível:\n");
    imprime_por_nivel(raiz);


    int nivel = 1; //Nivel inserido manualmente
    printf("Total de nós no nível %d: %d\n", nivel, contabiliza_nos_por_nivel(raiz, nivel));

    printf("\nRota até o valor %d:\n", chave_busca);
    imprime_rota_ate_valor(raiz, chave_busca);
    printf("\n");
    remove_no(raiz, 41);
    imprime_pre_ordem(raiz);

    return 0;
}