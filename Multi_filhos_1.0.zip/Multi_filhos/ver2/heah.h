#ifndef __HEAD_H__
#define __HEAD_H__

#include <stdlib.h>
#include <stdio.h>

#define MAX 3

struct est_no
{
    int chave;
    char letra;
};
typedef struct est_no tipo_no;

struct est_arv
{
    tipo_no* vet[MAX];
    int contador;
    struct est_arv* ponteiros[MAX+1];
};
typedef struct est_arv tipo_arv;

tipo_no* aloca_no(int, char);
tipo_arv* inicializar_arvore();
void inserir(tipo_arv**, int, char);
int encontrar_filho(tipo_arv*, char);
















#endif