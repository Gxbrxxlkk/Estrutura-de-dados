#include "heah.h"

tipo_no* aloca_no(int chave, char letra) {
    tipo_no* novo_no = (tipo_no*)malloc(sizeof(tipo_no));
    if (novo_no == NULL) exit(1);
    novo_no->chave = chave;
    novo_no->letra = letra;

    return novo_no;
}

tipo_arv* inicializar_arvore() {
    tipo_arv* nova_arv = (tipo_arv*)malloc(sizeof(tipo_arv));
    if(nova_arv == NULL) exit(1);

    nova_arv->contador = 0;

    for (size_t i = 0; i < MAX; i++)
        nova_arv->vet[i] = NULL;

    for (size_t i = 0; i < MAX+1; i++)
        nova_arv->ponteiros[i] = NULL;
    
    return nova_arv; 
}

void inserir(tipo_arv** arv, int chave, char letra) {
    //Caso a arvore não foi iniciada
    if (*arv == NULL) {
        *arv = inicializar_arvore(); 
        (*arv)->vet[(*arv)->contador++] = aloca_no(chave, letra);
    }
    tipo_arv* aux = *arv;

    //se o vet ainda tem espaço
    if (aux->contador < MAX) {
  
    int indice = aux->contador - 1;

    while (indice >= 0 && letra < aux->vet[indice]->letra) {
        
        aux->vet[indice + 1] = aux->vet[indice--];
    }

    aux->vet[++indice] = aloca_no(chave, letra);
    aux->contador++;
    } else { //Caso o vet esteja cheio, inserir nos filhos


    }       
}

int encontrar_filho(tipo_arv* arv, char letra) {

    int i = 0;
    while (i < arv->contador && letra > arv->vet[i]->letra) {
        i++;
    }
    
}