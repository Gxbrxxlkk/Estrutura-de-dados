#include "lista.h"

tipo_lista* aloca_no(int val) {
    tipo_lista* novo_no = (tipo_lista*)malloc(sizeof(tipo_lista));
    if (novo_no != NULL)
    {
        novo_no->valor = val;
        novo_no->prox = NULL;
        return novo_no;
    } else {
        printf("Erro ao alocar memória!\n");
        return NULL;
    }
}

void insereInicio(tipo_lista **lista, int val) {
    tipo_lista* novo_no = aloca_no(val);
    if ((*lista) == NULL)
    {
        (*lista) = novo_no; //acho que tá ao contrário, (tava ao contrário)
        return;
    } else
    {
        novo_no->prox = *lista;
        (*lista) = novo_no;
//talvez eu errei na lógica, (errei, estava atribuido o próximo do novo nó após modificar o primeiro da lista);
        return;
    }
}
void inserePos(tipo_lista** lista, int pos, int val) {
    if (pos == 0) {
    insereInicio(lista, val); //estava errado colocar &lista, já que lista já é um ponteiro duplo
    return;
    }
    tipo_lista* novo_no = aloca_no(val);
    
        int contador = 0;
        tipo_lista* aux = *lista;
        tipo_lista* aux_ant = NULL;

        while (aux != NULL && contador<pos) {
            aux_ant = aux;
            aux = aux->prox; //Só errei um ponteiro extra(maldito ponteiro)
            contador++;
        }
        if(aux_ant == NULL || contador != pos) {
            printf("Posição inválida!\n");
            free(novo_no);
            return;
        }
        aux_ant->prox = novo_no;
        novo_no->prox = aux;   //acerteo essa parte
}

void insereFim(tipo_lista** lista, int val) {
    tipo_lista* novo_no = aloca_no(val);
    if (*lista == NULL) //Não tinha colocado esse caso
    {
        *lista = novo_no;
        return;
    }
    
    tipo_lista* aux = *lista; //Não precisava de auxiliar anteiror
    while (aux->prox != NULL) { //antes tava colocando novo nó no vento
        aux = aux->prox;
    }
    aux->prox = novo_no;
}

int removeInicio(tipo_lista** lista) {
    if (*lista == NULL)
    {
        return -1; //Caso a lista esteja vazia
    } else {
        int val;
        tipo_lista* aux = (*lista);
        val = aux->valor;
        (*lista) = aux->prox;
        free(aux);
        return val;
    }
}

int removePos(tipo_lista** lista, int pos) {
    if(*lista == NULL)
    return -1;

    //Não tinha feito a verificação de lista vazia
    if (pos == 0)
    {
        return removeInicio(lista);
    }
    tipo_lista* aux = (*lista);
    tipo_lista* aux_ant = NULL;
    int contador = 0, val;
    while (aux != NULL && contador<pos) {
        aux_ant = aux;
        aux = aux->prox; 
        contador++;
    }
    val = aux->valor;
    aux_ant->prox = aux->prox; //pedi a logica com o gpt
    free(aux);
    return val;
}

int removeFim(tipo_lista** lista) {
    if(*lista == NULL) {
        return -1; // Não tinha feito o caso da lista estar vazia
    }

    tipo_lista* aux = (*lista);
    tipo_lista* aux_ant = NULL;

    //também não fiz um caso se tivesse um unico elemento
    if (aux->prox == NULL)
    {
        int val = aux->valor;
        free(aux);
        *lista = NULL;
        return val;
    }
    
    while (aux->prox != NULL) { //mesmo erro que insere fim (copiei e colei mesmo)
        
        aux_ant = aux;
        aux = aux->prox;
    }
    int val = aux->valor; // para economizar linha
    //val = aux->valor;
    aux_ant->prox = NULL;
    free(aux);
    return val;
}

void imprimeLista(tipo_lista* lista) {

    if (lista == NULL)
    {
        printf("Lista vazia!\n");
        return;
    } 
    while (lista != NULL)
    {
        printf(" [%d] ", lista->valor);
        lista = lista->prox;
    }
}