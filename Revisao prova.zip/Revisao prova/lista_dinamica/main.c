#include "lista.h"

int main() {

    tipo_lista* minha_lista;
    minha_lista = NULL;

    insereInicio(&minha_lista, 15);
    insereInicio(&minha_lista, 10);
    insereFim(&minha_lista, 40);
    inserePos(&minha_lista, 1, 42);
    imprimeLista(minha_lista);
    printf("\n");
    printf("Valor removido por posição: %d\n", removePos(&minha_lista, 1));
    printf("Valor removido inicio: %d\n", removeInicio(&minha_lista));
    printf("Valor removido do fim: %d\n", removeFim(&minha_lista));
    imprimeLista(minha_lista);

    return 0;
}