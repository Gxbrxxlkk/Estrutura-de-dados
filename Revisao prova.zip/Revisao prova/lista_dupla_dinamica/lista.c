#include "lista.h"

tipo_lista_dupla* aloca_no(int val) {
    tipo_lista_dupla* novo_no = (tipo_lista_dupla*)malloc(sizeof(tipo_lista_dupla));
    if (novo_no == NULL)
    {
        printf("Erro ao alocar memória");
        exit(1); //Uso legal para não ter que verificar em toda função se o nó é nulo, (1 deu erro, 0 deu bom)
    } else {
        novo_no->ant = NULL;
        novo_no->prox = NULL;
        return novo_no;
    }
}

void inserirInicio(tipo_lista_dupla** lista, int val) {
    tipo_lista_dupla* novo_no = aloca_no(val);
    
    if (*lista == NULL) {
        (*lista) = novo_no;
    } else {
        novo_no->prox = (*lista);
        (*lista)->ant = novo_no;
        (*lista) = novo_no;
    }
    return;   
}

void inserirFim(tipo_lista_dupla** lista, int val) {

    if (*lista == NULL) inserirInicio(lista, val); //Se a lista estiver vazia, executa a função inserirInicio
    
    else {
        tipo_lista_dupla* novo_no = aloca_no(val);
        tipo_lista_dupla* aux = (*lista);
        while (aux->prox != NULL) {
            aux = aux->prox;
        }
        aux->prox = novo_no;
        novo_no->ant = aux;
    }
}

void inserirPos(tipo_lista_dupla** lista, int posicao, int val) {
    if (posicao == 0) { 
    inserirInicio(lista, val); //caso a posição seja o inicio
    return;
    }
    tipo_lista_dupla* novo_no = aloca_no(val);
    tipo_lista_dupla* aux = (*lista);
    int contador = 0;

    while (aux->prox != NULL && contador<posicao - 1) //meu auxiliar vai ficar na posição que eu quero inserir
    {
        aux = aux->prox;
        contador++;
    }
    if (aux->prox == NULL) {
        aux->prox = novo_no; //Mesma lógica que inserir no fim
        novo_no->ant = aux;
    } else {
        novo_no->prox = aux->prox;
        aux->prox->ant = novo_no;
        aux->prox = novo_no;
        novo_no->ant = aux;
    }
}

int removerInicio(tipo_lista_dupla** lista) {

    if (*lista == NULL) { //caso a lista está vazia
        printf("Erro, lista está vazia");
        return -1;
    }
    tipo_lista_dupla* aux = *lista;
    int val = aux->valor;
    if (aux->prox == NULL) {    //Caso tenha só um elemento 
        *lista = NULL;
    } else {
        *lista = aux->prox;
        (*lista)->ant = NULL;
    }
        free(aux);
        return val;
}

int removerFim(tipo_lista_dupla** lista) {
    if (*lista = NULL)
    {
        printf("Lista vazia!\n");
        return -1;
    }
    if ((*lista)->prox == NULL) //caso tenha um elemento
    {
        return removerInicio(lista);
    }
    tipo_lista_dupla* aux = *lista;
    while (aux->prox != NULL)
    {
        aux = aux->prox;
    }
    aux->ant->prox = NULL;
    int val = aux->valor;
    free(aux);
    return val;
}

int removerPos(tipo_lista_dupla** lista, int posicao) {
    if (*lista == NULL)
    {
        printf("Não é possivel remover!\n");
        return -1;
    }
    if (posicao == 0)
        return removerInicio(lista);
    else {
        tipo_lista_dupla* aux = *lista;
        int contador;
        while (aux->prox != NULL && contador < posicao - 1)
        {
            aux = aux->prox;
            contador++;
        }
        
        
    }
}