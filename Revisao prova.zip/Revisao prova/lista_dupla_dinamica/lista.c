#include "lista.h"

tipo_lista_dupla* aloca_no(int val) {
    tipo_lista_dupla* novo_no = (tipo_lista_dupla*)malloc(sizeof(tipo_lista_dupla));
    if (novo_no == NULL)
    {
        printf("Erro ao alocar memória");
        exit(1); //Uso legal para não ter que verificar em toda função se o nó é nulo, (1 deu erro, 0 deu bom)
    } else {
        novo_no->ant = NULL;
        novo_no->prox = NULL;
        return novo_no;
    }
}

void inserirInicio(tipo_lista_dupla** lista, int val) {
    tipo_lista_dupla* novo_no = aloca_no(val);
    
    if (*lista == NULL) {
        (*lista) = novo_no;
    } else {
        novo_no->prox = (*lista);
        (*lista)->ant = novo_no;
        (*lista) = novo_no;
    }
    return;   
}

void inserirFim(tipo_lista_dupla** lista, int val) {

    if (*lista == NULL) inserirInicio(lista, val); //Se a lista estiver vazia, executa a função inserirInicio
    
    else {
        tipo_lista_dupla* novo_no = aloca_no(val);
        tipo_lista_dupla* aux = (*lista);
        while (aux->prox != NULL) {
            aux = aux->prox;
        }
        aux->prox = novo_no;
        novo_no->ant = aux;
    }
}

void inserirPos(tipo_lista_dupla** lista, int posicao, int val) {
    if (posicao == 0) inserirInicio(lista, val); //caso a posição seja o inicio

    tipo_lista_dupla* novo_no = aloca_no(val);
    tipo_lista_dupla* aux = (*lista);
    int contador = 0;

    while (aux->prox != NULL && contador<posicao - 1) //meu auxiliar vai ficar na posição que eu quero inserir
    {
        aux = aux->prox;
        contador++;
    }
    if (aux->prox == NULL) {
        aux->prox = novo_no; //Mesma lógica que inserir no fim
        novo_no->ant = aux;
    }
    
    
    
    

    
}