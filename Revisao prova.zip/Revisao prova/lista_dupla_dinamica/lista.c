#include "lista.h"

tipo_lista* aloca_no(int val) {
    tipo_lista* novo_no = (tipo_lista*)malloc(sizeof(tipo_lista));
    if (novo_no != NULL)
    {
        novo_no->valor = val;
        novo_no->prox = NULL;
        novo_no->ant = NULL;
        return novo_no;
    } else {
        printf("Erro ao alocar memória!\n");
        return NULL;
    }
}

void insereInicio(tipo_lista **lista, int val) {
    tipo_lista* novo_no = aloca_no(val);
    if ((*lista) == NULL)
    {
        *lista = novo_no; //acho que tá ao contrário, (tava ao contrário)
    } else
    {
        novo_no->prox = *lista;
        (*lista)->ant = novo_no;
        *lista = novo_no;
//talvez eu errei na lógica, (errei, estava atribuido o próximo do novo nó após modificar o primeiro da lista);

    }
}
void inserePos(tipo_lista** lista, int pos, int val) {
    if (pos == 0) {
    insereInicio(lista, val); //estava errado colocar &lista, já que lista já é um ponteiro duplo
    return;
    }
    
    tipo_lista* novo_no = aloca_no(val);
    tipo_lista* aux = *lista;
    int contador = 0;
    
    while (aux != NULL && contador<pos-1) {
        aux = aux->prox;
        //Só errei um ponteiro extra(maldito ponteiro)
        contador++;
    }
    if(aux == NULL ) { //robozão pediu pra tirar o ou, vou ver se ele vai colocar de volta daqui a pouco
        printf("Posição inválida!\n");
        free(novo_no);
        return;
    }
    novo_no->prox = aux->prox;   //acerteo essa parte
    novo_no->ant = aux;
    if (aux->prox != NULL) {
        aux->prox->ant = novo_no;
    }
    aux->ant = novo_no;
}

void insereFim(tipo_lista** lista, int val) {
    tipo_lista* novo_no = aloca_no(val);
    if (*lista == NULL) //Não tinha colocado esse caso
    {
        *lista = novo_no;
        return;
    }
    
    tipo_lista* aux = *lista; //Não precisava de auxiliar anteiror
    while (aux->prox != NULL) { //antes tava colocando novo nó no vento
        aux = aux->prox;
    }
    aux->prox = novo_no; //Basicamente onde tem pra atribuir ao proximo tem que atribuir o anteiror (dupla encadeiada)
    novo_no->ant = aux;
}

int removeInicio(tipo_lista** lista) {
    if (*lista == NULL)
    {
        return -1; //Caso a lista esteja vazia
    } else {
        tipo_lista* aux = (*lista);
        int val = aux->valor;
        (*lista) = aux->prox;
        if (*lista != NULL)
        {
            (*lista)->ant = NULL;
        }
        free(aux);
        return val;
    }
}

int removePos(tipo_lista** lista, int pos) {
    if(*lista == NULL) return -1;
    
    tipo_lista* aux = (*lista);
    int contador = 0, val;
    //Não tinha feito a verificação de lista vazia
    /*if (pos == 0)
    {
        return removeInicio(lista);
    }*/
    while (aux != NULL && contador<pos) {
        aux = aux->prox; 
        contador++;
    }
    if (aux == NULL)
        return -1;

    val = aux->valor;
    if (aux->ant != NULL) {
        aux->ant->prox = aux->prox;
     } else {
        *lista = aux->prox;
      } //pedi a logica com o gpt
    if (aux->prox != NULL)
    {
        aux->prox->ant = aux->ant;
    }
    
    free(aux);
    return val;
}

int removeFim(tipo_lista** lista) {
    if(*lista == NULL)
        return -1; // Não tinha feito o caso da lista estar vazia
    

    tipo_lista* aux = *lista;

    //também não fiz um caso se tivesse um unico elemento
    
    while (aux->prox != NULL) { //mesmo erro que insere fim (copiei e colei mesmo)
        aux = aux->prox;
    }
    int val = aux->valor; // para economizar linha
    //val = aux->valor;
    if (aux->ant != NULL)
    {
        aux->ant->prox = NULL;
    } else {
        *lista = NULL;
    } //Basicamente tirou o if de caso um elemento e fez um if else para o caso geral e 1 elemtno
    free(aux);
    return val;
}

void imprimeLista(tipo_lista* lista) {

    if (lista == NULL)
    {
        printf("Lista vazia!\n");
        return;
    } 
    while (lista != NULL)
    {
        printf(" [%d] ", lista->valor);
        lista = lista->prox;
    }
}