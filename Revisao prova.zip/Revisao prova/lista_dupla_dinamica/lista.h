#ifndef __LISTA_H__
#define __LISTA_H__

#include <stdio.h>
#include <stdlib.h>

struct est_no
{
    struct est_no* ant;
    int valor;
    struct est_no* prox;
};
typedef struct est_no tipo_lista_dupla;

//Protótipó das função

tipo_lista_dupla* aloca_no(int);
void inserirInicio(tipo_lista_dupla**, int);
void inserirFim(tipo_lista_dupla**, int);
void inserirPos(tipo_lista_dupla**, int posicao, int);
int removerInicio(tipo_lista_dupla**);
int removerFim(tipo_lista_dupla**);
int removerPos(tipo_lista_dupla**, int posicao);
void imprimirLista(tipo_lista_dupla*);
//12:54 --> isso vai dar um puta trabalho

#endif //__LISTA_H__