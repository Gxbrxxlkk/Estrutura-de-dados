#ifndef __LISTA_H__
#define __LISTA_H__

#include <stdio.h>
#include <stdlib.h>

struct est_no
{
    int valor;
    struct est_no* prox;
    struct est_no* ant;
};
typedef struct est_no tipo_lista;

tipo_lista* aloca_no(int);
void insereInicio(tipo_lista**, int);
void inserePos(tipo_lista**, int pos, int);
void insereFim(tipo_lista**, int);
int removeInicio(tipo_lista**);
int removePos(tipo_lista**, int pos);
int removeFim(tipo_lista**);
void imprimeLista(tipo_lista*);

#endif // __LISTA_H__