#include "fila.h"

int main() {
    tipo_fila* minhaFila = NULL;

    
    // Testando inserção na fila
    insereFila(&minhaFila, 10);
    insereFila(&minhaFila, 20);
    insereFila(&minhaFila, 30);
    
    // Imprimindo a fila
    printf("Fila apos insercoes:\n");
    imprimeFila(minhaFila);
    printf("\n");
    
    // Removendo um elemento
    int removido = removeFila(&minhaFila);
    printf("Elemento removido: %d\n", removido);
    
    // Imprimindo a fila apos a remocao
    printf("Fila apos remocao:\n");
    imprimeFila(minhaFila);
    printf("\n");
    
    return 0;
}
