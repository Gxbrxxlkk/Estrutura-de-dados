#include "fila.h"

tipo_fila* aloca_no(int val) {
    tipo_fila* novo_no = (tipo_fila*)malloc(sizeof(tipo_fila));
    if (novo_no == NULL)
    {
        printf("Não foi possivel alocar memoria");
        return NULL;
    } else{ 
        novo_no->prox = NULL;
        novo_no->valor = val;
        return novo_no;
    }
}

void insereFila(tipo_fila** fl, int val) {

    tipo_fila* novo_no = aloca_no(val);
    if (*fl == NULL)
    {
        (*fl) = novo_no;
    } else {
        tipo_fila* aux =(*fl);
        while (aux->prox != NULL)
        {
            aux = aux->prox;
        }
        aux->prox = novo_no;
    }
}

int removeFila(tipo_fila** fila) {

    tipo_fila* aux;
    int val;

    if ((*fila) != NULL)    
    {
        val = (*fila)->valor;
        aux = *fila;
        (*fila) = (*fila)->prox ;
        free(aux);
        return val;
    } else
    {
        return -1;
    }
}

void imprimeFila(tipo_fila* fila) {
tipo_fila* aux = fila;
    printf("Fila -> ");
    while (aux != NULL)
    {
        printf("[%d] ", aux->valor);
        aux = aux->prox;
    }
}
