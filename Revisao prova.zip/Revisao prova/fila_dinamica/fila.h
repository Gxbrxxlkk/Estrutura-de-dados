#ifndef __FILA_H__ 
#define __FILA_H__

#include <stdlib.h>
#include <stdio.h>

struct est_no
{
    int valor;
    struct est_no* prox;
};
typedef struct est_no tipo_fila;

//Prototipacao
tipo_fila *aloca_no(int);
void insereFila(tipo_fila **, int);
int removeFila(tipo_fila**);
void imprimeFila(tipo_fila*);

#endif //__FILA_H__